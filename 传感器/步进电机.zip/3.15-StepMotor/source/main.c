#include <ioCC2530.h>
#include "sys_init.h"

#define AA      P0_5          
#define BB      P0_1 
#define CC      P0_6
#define DD      P1_3 

void motor_init(void);
void Motor_Test(void);

char Flag = 0;

/*������
-------------------------------------------------------*/
void main(void)
{ 
  xtal_init();
  ext_init(); 
  motor_init();
  
  while(1)
  {
    Motor_Test();
  }
}

/*motor_init����
-------------------------------------------------------*/
void motor_init(void)
{
  P0SEL &=~ 0x62;   //P0_1 P0_5 P0_6 Ϊ��ͨio��
  P0DIR |= 0x62;    //�����
  
  P1SEL &=~ 0x08;   //P1_3Ϊ��ͨio�� 
  P1DIR |= 0x08;    //�����
  
  AA = 1;
  BB = 1;
  CC = 1;
  DD = 1;
}

/*Motor_Test����
-------------------------------------------------------*/
void Motor_Test(void)
{
    if(0 == Flag)    //forward
    {
      AA = 1;
      BB = 0;
      CC = 0;
      DD = 1;
      halWait(1);
      
      AA = 0;
      BB = 0;
      CC = 0;
      DD = 1;
      halWait(1);
      
      AA = 0;
      BB = 0;
      CC = 1;
      DD = 1;
      halWait(1);
      
      AA = 0;
      BB = 0;
      CC = 1;
      DD = 0;
      halWait(1);
      
      AA = 0;
      BB = 1;
      CC = 1;
      DD = 0;
      halWait(1);
      
      AA = 0;
      BB = 1;
      CC = 0;
      DD = 0;
      halWait(1);
      
      AA = 1;
      BB = 1;
      CC = 0;
      DD = 0;
      halWait(1);
      
      AA = 1;
      BB = 0;
      CC = 0;
      DD = 0;   
      halWait(1);
    }
   
    else if(1 == Flag)    //reverse
    {
      AA = 1;
      BB = 0;
      CC = 0;
      DD = 0;   
      halWait(1);
      
      AA = 1;
      BB = 1;
      CC = 0;
      DD = 0;
      halWait(1);
      
      AA = 0;
      BB = 1;
      CC = 0;
      DD = 0;
      halWait(1);
      
      AA = 0;
      BB = 1;
      CC = 1;
      DD = 0;
      halWait(1);
      
      AA = 0;
      BB = 0;
      CC = 1;
      DD = 0;
      halWait(1);
      
      AA = 0;
      BB = 0;
      CC = 1;
      DD = 1;
      halWait(1);
      
      AA = 0;
      BB = 0;
      CC = 0;
      DD = 1;
      halWait(1);
      
      AA = 1;
      BB = 0;
      CC = 0;
      DD = 1;
      halWait(1);
    }
}

/*�жϷ����ӳ���
-------------------------------------------------------*/
#pragma vector = P0INT_VECTOR
__interrupt void P0_ISR(void)
{
  EA = 0;                         //���ж�
  
  halWait(200);                    //ȥ����    
  
  if((P0IFG & 0x10 ) >0 )         //����K5�ж� ,P0_4
  {
    Flag = (Flag+1)%2;
    P0IFG &= ~0x10;               //P0_4�жϱ�־��0    
  }
  P0IF = 0;                       //P0�жϱ�־��0
  EA = 1;                         //���ж�
}